package com.example.konvertervaluta_srsic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Spinner sp1,sp2;
    EditText ed1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.iznos);
        sp1=findViewById(R.id.Iz);
        sp2=findViewById(R.id.U);
        b1=findViewById(R.id.btn1);

        String[] Iz ={"HRK"};
        ArrayAdapter ad = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,Iz);
        sp1.setAdapter(ad);

        String[]U={"EUR","USD","CHF"};
        ArrayAdapter ad1 = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,U);
        sp2.setAdapter(ad1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double ukupno;
                Double iznos = Double.parseDouble(ed1.getText().toString());

                if (sp1.getSelectedItem().toString()=="HRK" && sp2.getSelectedItem().toString()=="EUR"){
                    ukupno=iznos/7.53450;
                    Toast.makeText(getApplicationContext(),ukupno.toString(),Toast.LENGTH_LONG).show();
                } else if (sp1.getSelectedItem().toString()=="HRK" && sp2.getSelectedItem().toString()=="USD"){
                    ukupno=iznos/6.91883;
                    Toast.makeText(getApplicationContext(),ukupno.toString(),Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString()=="HRK" && sp2.getSelectedItem().toString()=="CHF"){
                    ukupno=iznos/7.52289;
                    Toast.makeText(getApplicationContext(),ukupno.toString(),Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}